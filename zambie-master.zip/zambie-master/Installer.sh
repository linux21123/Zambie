sudo apt-get update
pip install termcolor
sudo apt-get install libssl-dev
sudo apt-get install masscan
sudo apt-get install perl
sudo apt-get install libwww-mechanize-shell-perl
sudo apt-get install perl-mechanize
sudo apt-get install slowhttptest

